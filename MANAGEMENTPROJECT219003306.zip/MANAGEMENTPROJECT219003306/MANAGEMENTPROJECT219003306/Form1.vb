﻿Public Class Form1
    Private Sub ClubsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClubsToolStripMenuItem.Click
        Clubs.Show()
    End Sub

    Private Sub StudentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentsToolStripMenuItem.Click
        Students.Show()
    End Sub

    Private Sub EventsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EventsToolStripMenuItem.Click
        Dim even As New Events
        even.Show()
    End Sub

    Private Sub MembershipToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MembershipToolStripMenuItem.Click
        Memberships.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
    End Sub
End Class
