﻿Public Class Clubs
    Private Sub Clubs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        viewdata()

    End Sub
    Sub viewdata()
        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "Select * from Clubs"
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
        End Try
    End Sub
    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Dim sql As String
        Try
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            Dim clubId As String = cludidTextb.Text
            Dim ClubName As String = clubnameTB.Text



            sql = "UPDATE Clubs SET ClubName='" & ClubName & "' WHERE ClubId='" & clubId & "'"
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            ' MsgBox("Student with this reg number" & reg & " is updated!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles cludidTextb.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles presidentTB.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim query As String = String.Empty

        Dim clubid As String = cludidTextb.Text

        Dim clubname As String = clubnameTB.Text
        Dim president As String = presidentTB.Text
        Dim nberofmembers As String = nberTB.Text

        query &= "INSERT INTO Clubs(ClubId,ClubName,President,nberofmembers)"
        query &= "VALUES (@ClubId,@ClubName,@President,@nberofmembers)"


        cm = New OleDb.OleDbCommand

        With cm
            .Connection = cn
            .CommandType = CommandType.Text
            .CommandText = query
            .Parameters.AddWithValue("@ClubId", clubid)
            .Parameters.AddWithValue("@ClubName", clubname)
            .Parameters.AddWithValue("@President", President)
            .Parameters.AddWithValue("@nberofmembers", nberofmembers)


        End With
        Try
            If (cludidTextb.Text <> Nothing And clubnameTB.Text <> Nothing) Then
                cm.ExecuteNonQuery()
                MsgBox("Well Inserted")
                viewdata()
                clubnameTB.Clear()
                cludidTextb.Clear()

            Else
                MsgBox("Please fill all info")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString(), "Error Message")
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            Dim cid As Int32 = CInt(cludidTextb.Text)

            sql = "DELETE * from Clubs WHERE ClubId=" & cid & ""
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            MsgBox("club with this clubid" & cid & " is delted!")
            viewdata()
            ' search_reg.Clear()
            'search_name.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub
End Class