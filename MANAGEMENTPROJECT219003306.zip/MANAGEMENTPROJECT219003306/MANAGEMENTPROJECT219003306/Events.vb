﻿Public Class Events
    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter
        viewdata()
    End Sub
    Sub viewdata()
        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "Select * from Events"
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter
        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "Select * from Events"
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
        End Try
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim query As String = String.Empty

        Dim eventid As String = eventidTB.Text

        Dim clubids As String = clubiddTB.Text
        Dim eventname As String = eventnameTB.Text
        Dim dates As String = datesTB.Text
        Dim attendance As String = attendancesTB.Text

        query &= "INSERT INTO Events(EventId,ClubId,EventName,Dates,Attendance)"
        query &= "VALUES (@eventid,@clubids,@eventname,@dates,@attendance)"


        cm = New OleDb.OleDbCommand

        With cm
            .Connection = cn
            .CommandType = CommandType.Text
            .CommandText = query
            .Parameters.AddWithValue("@EventId", eventid)
            .Parameters.AddWithValue("@ClubId", clubids)
            .Parameters.AddWithValue("@EventName", eventname)
            .Parameters.AddWithValue("@Dates", dates)
            .Parameters.AddWithValue("@Attendance", attendance)


        End With
        Try
            If (eventidTB.Text <> Nothing And clubiddTB.Text <> Nothing) Then
                cm.ExecuteNonQuery()
                MsgBox("Well Inserted")
                viewdata()
                ' clubnameTB.Clear()
                ' cludidTextb.Clear()

            Else
                MsgBox("Please fill all info")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString(), "Error Message")
        End Try
    End Sub

    Private Sub datesTB_TextChanged(sender As Object, e As EventArgs) Handles datesTB.TextChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            Dim cid As Int32 = CInt(eventidTB.Text)

            sql = "DELETE * from Clubs WHERE ClubId=" & cid & ""
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            MsgBox("club with this clubid" & cid & " is delted!")
            'viewdata()
            ' search_reg.Clear()
            'search_name.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub
End Class

